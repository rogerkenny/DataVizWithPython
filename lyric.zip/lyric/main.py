# coding: utf-8
import random
import json

def _k(path):
	return '+'.join(path)

def chooseNext(paths, path):
	# print("chooseNext", path)
	pkey = _k(path)
	# print("_k", pkey)
	if not pkey in paths:
		return None
	nodes = []
	weights = []
	for n, w in paths[pkey].items():
		nodes.append(n)
		weights.append(w)
	return random.choices(nodes, weights)[0]
	

def generate(paths, maxWords=20, seed='', pathLen=1, temp=1):
	out = seed.split(' ')
	s = seed.split(' ')
	while len(out) < maxWords:
		#print("generate", out, s)
		a = 1 if random.random() <= temp else 0
		v = a * random.randint(0,len(s)-1)
		#print(v, s[v:])
		next = chooseNext(paths, s[v:])
		if next == None:
			out.pop()
			s=['']
			continue
		out.append(next)
		s = out[(-1 * pathLen):]
	return out
	

def makegrunge():
	out = ''
	out += '='*40 + "\n"
	out += (" ".join(generate(p, pathLen=pLen, seed='', maxWords=maxWords, temp=0.22))).strip()
	return out
	
pLen = 3
dumpFile = 'PDump.json'
maxWords = 50

inFile = open(dumpFile, 'r')
p = json.load(inFile)
inFile.close()
